The project is written in Java 8 with JavaFX API

Compile the code: 
javac AnimalLogicTask.java
java AnimalLogicTask

How to use:
0. Select a input text file(*.txt)
1. Input two words for prefix, 
2. Input one word for suffix,
3. Input maximum number of words for the "random text" 

4. Click on "Generate Text"

